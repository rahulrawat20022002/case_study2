# Correctness (predicted label vs frozen Commission ground truth)

Positive class = high-risk. Accuracy plus per-class precision/recall/F1 because the set is imbalanced (frozen). Parse failures counted as incorrect and also shown separately.

| Config | n | Accuracy | HR precision | HR recall | HR F1 | Macro F1 | Parse fails |
|---|---|---|---|---|---|---|---|
| agent_structured | 215 | 0.958 | 0.913 | 0.955 | 0.933 | 0.951 | 0 |
| baseline1_plain_llm | 215 | 0.833 | 0.653 | 0.970 | 0.780 | 0.823 | 0 |
| baseline2_standard_rag | 215 | 0.935 | 0.842 | 0.970 | 0.901 | 0.926 | 0 |

## agent_structured

Confusion (high-risk positive): tp=63 fp=6 fn=3 tn=143

By edge-case type: article-6-3-filter n=41 acc=0.927, none n=174 acc=0.966

By area: biometrics 0.938, critical-infrastructure 0.889, education 0.964, employment 1.000, essential-services 1.000, justice-democracy 0.938, law-enforcement 0.913, migration 0.957

## baseline1_plain_llm

Confusion (high-risk positive): tp=64 fp=34 fn=2 tn=115

By edge-case type: article-6-3-filter n=41 acc=0.976, none n=174 acc=0.799

By area: biometrics 0.594, critical-infrastructure 0.833, education 0.964, employment 1.000, essential-services 0.907, justice-democracy 0.812, law-enforcement 0.478, migration 1.000

## baseline2_standard_rag

Confusion (high-risk positive): tp=64 fp=12 fn=2 tn=137

By edge-case type: article-6-3-filter n=41 acc=0.829, none n=174 acc=0.960

By area: biometrics 0.906, critical-infrastructure 0.889, education 0.964, employment 1.000, essential-services 0.907, justice-democracy 0.938, law-enforcement 0.913, migration 0.957
