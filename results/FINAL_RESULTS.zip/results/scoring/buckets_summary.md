# Four-bucket outcome matrix (correctness x faithfulness)

Faithful threshold = 0.5 (a reporting choice; sweep and continuous stats below so nothing rests on it). Off-diagonal buckets are the findings: **wrong + faithful** is the headline 'faithful but wrong'.

## agent_structured

Joined & scored rows: 215  (unscored, no faithfulness: 0)

| | faithful | unfaithful |
|---|---|---|
| **label right** | 100 | 106 |
| **label wrong** | 3 | 6 |

Mean faithfulness when label right: 0.471
Mean faithfulness when label wrong: 0.451
Point-biserial corr(correct, faithfulness): 0.013

Bucket counts across faithful thresholds:

| threshold | right+faithful | right+unfaithful | wrong+faithful | wrong+unfaithful |
|---|---|---|---|---|
| 0.3 | 132 | 74 | 6 | 3 |
| 0.5 | 100 | 106 | 3 | 6 |
| 0.7 | 57 | 149 | 2 | 7 |
| 0.9 | 16 | 190 | 0 | 9 |
| 1.0 | 16 | 190 | 0 | 9 |

## baseline2_standard_rag

Joined & scored rows: 215  (unscored, no faithfulness: 0)

| | faithful | unfaithful |
|---|---|---|
| **label right** | 108 | 93 |
| **label wrong** | 6 | 8 |

Mean faithfulness when label right: 0.518
Mean faithfulness when label wrong: 0.456
Point-biserial corr(correct, faithfulness): 0.060

Bucket counts across faithful thresholds:

| threshold | right+faithful | right+unfaithful | wrong+faithful | wrong+unfaithful |
|---|---|---|---|---|
| 0.3 | 150 | 51 | 8 | 6 |
| 0.5 | 108 | 93 | 6 | 8 |
| 0.7 | 58 | 143 | 3 | 11 |
| 0.9 | 15 | 186 | 0 | 14 |
| 1.0 | 15 | 186 | 0 | 14 |
